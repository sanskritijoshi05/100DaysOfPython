# 🚀 Day 2: <Project Title Here>

This is Day 2 of my **#100DaysOfPython** challenge.

---

## 💡 What You’ll Learn
- <Highlight key concepts practiced today>

---

## 📦 How to Run

```bash
python main.py
```

---

## 🧪 Sample Output

```
<Include sample terminal output if relevant>
```

---

## 🔗 GitHub Link

📁 [View on GitHub](https://github.com/sanskritijoshi05/100DaysOfPython/tree/main/Day2-ProjectName)

---

## ✍️ Notes & Reflections

<Write your learnings, challenges, and reflections here>

---

## 📅 Day 2 Complete — 98 more to go!
